export class CriarReserva {
  nomeCliente: string;
  mesaId: number;
  data: string;
  horaInicial: string;
  funcionarioId: number;
  telefone: number;

  constructor(
    nomeCliente: string,
    mesaId: number,
    data: string,
    horaInicial: string,
    funcionarioId: number,
    telefone: number,
  ) {
    this.nomeCliente = nomeCliente;
    this.mesaId = mesaId;
    this.data = data;
    this.horaInicial = horaInicial;
    this.funcionarioId = funcionarioId;
    this.telefone = telefone;
  }
}
