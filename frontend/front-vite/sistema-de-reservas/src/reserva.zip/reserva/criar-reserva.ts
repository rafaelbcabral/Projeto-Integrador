export interface Reserva {
  nomeCliente: string;
  mesa: number;
  data: string;
  horaInicial: string;
  funcionario: number;
  telefone: number;
}
