// Interface de Reserva para listar
export interface ReservaListar {
  id: string;
  nomeCliente: string;
  mesa: string;
  data: string;
  inicio: string;
  fim: string;
  nomeFuncionario: string;
  status: string;
}
