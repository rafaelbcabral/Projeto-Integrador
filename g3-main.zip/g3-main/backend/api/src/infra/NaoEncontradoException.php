<?php
class NaoEncontradoException extends DominioException {}

?>