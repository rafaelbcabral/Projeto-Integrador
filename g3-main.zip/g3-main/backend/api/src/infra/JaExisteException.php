<?php
class JaExisteException extends DominioException {}

?>