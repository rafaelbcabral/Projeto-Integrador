import { describe, it, expect, vi } from 'vitest';
import { ControladoraFuncionarios } from '../../../src/funcionario/funcionario-controller';
import { GestorFuncionarios } from '../../../src/funcionario/gestor-funcionario';
import { VisaoFuncionarios } from '../../../src/funcionario/visao-funcionario';
