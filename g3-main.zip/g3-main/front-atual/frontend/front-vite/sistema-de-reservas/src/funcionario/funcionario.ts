export interface Funcionario {
  id: number;
  nome: string;
}
