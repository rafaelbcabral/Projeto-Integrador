export interface Mesa {
  id: string;
  capacidade: number;
}
