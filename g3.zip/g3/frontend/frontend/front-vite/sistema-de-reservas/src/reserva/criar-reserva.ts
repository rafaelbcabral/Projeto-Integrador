export interface Reserva {
  nomeCliente: string;
  mesa: number;
  data: string;
  horarioInicial: string;
  funcionario: number;
}
