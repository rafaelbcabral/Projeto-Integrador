# Projeto Integrador - P1
## Alunos: Rafael Botelho Cabral e Ramon Souza da Silva

### 📋 Descrição do Projeto
Este projeto é desenvolvido como parte do Projeto Integrador P1, focando na aplicação de conceitos teóricos e práticos aprendidos ao longo do curso. O objetivo principal é integrar diferentes disciplinas, proporcionando uma visão ampla e uma experiência prática no desenvolvimento de soluções.

### Comandos necessários para pôr o projeto em funcionamento
🧱🔨(em andamento...)


### Referências bibliográficas ou locais de onde foram obtidas
🧱🔨(em andamento...)
imagens, estilos CSS, ou outros recursos aplicáveis. Indicar o
que foi obtido de cada local.