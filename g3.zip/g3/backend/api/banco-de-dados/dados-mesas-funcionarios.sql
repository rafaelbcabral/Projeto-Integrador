-- Inserir dados na tabela mesa
INSERT INTO mesa (numero) VALUES 
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10);

-- Inserir dados na tabela funcionario
INSERT INTO funcionario (nome, usuario, senha) VALUES 
('João Silva', 'joao.silva', 'senha123'),
('Maria Oliveira', 'maria.oliveira', 'senha456'),
('Carlos Souza', 'carlos.souza', 'senha789');

