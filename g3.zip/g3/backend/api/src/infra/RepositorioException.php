<?php
class RepositorioException extends RuntimeException {}
?>